/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author Valentina
 */
public class Astronauta extends UnidadOperativa implements Reubicable
{
    private int eva;

    public Astronauta(int eva, String numeroID, String modulo, TipoAtmosfera tipoatmosfera) 
    {
        super(numeroID, modulo, tipoatmosfera);
        this.eva = eva;
    }
    
    //Puede moverse entre modulos
    
    @Override
    public void reabastecer() 
    {
        System.out.println("Recargando suministros personales.");
    }

    @Override
    public void mantenerAtmosfera() 
    {
        System.out.println("Verificando niveles de oxigeno para sobrevivir.");
    }

    @Override
    public void replicar() 
    {
        System.out.println("Entrenando nuevo astronauta.");
    }

    @Override
    public void moverA() 
    {
        System.out.println("Los astronautas se están desplazando de módulo");
    }
    
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        
        sb.append(super.toString());
        sb.append("\nEsta unidad es un: Astronauta\n");
        sb.append("Cantidad máxima de horas de actividad vehicular: ").append(this.eva);
        
        return sb.toString();
    }
}
