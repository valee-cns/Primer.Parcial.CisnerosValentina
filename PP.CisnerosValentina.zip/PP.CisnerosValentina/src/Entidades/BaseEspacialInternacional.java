/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.util.ArrayList;

/**
 *
 * @author Valentina
 */
public class BaseEspacialInternacional 
{
    private String nombre;
    private ArrayList<UnidadOperativa> unidades;

    public BaseEspacialInternacional(String nombre) 
    {
        this.nombre = nombre;
        this.unidades = new ArrayList<>();
    }
    
    public void agregarUnidadOperativa(UnidadOperativa e) throws ErrorUnidadDuplicada 
    {
        for (UnidadOperativa u : unidades) 
        {
            if (u.equals(e)) 
            {
                throw new ErrorUnidadDuplicada("Ya existe una unidad con nombre '"
                        + e.getNombreID() + "' en el módulo '" + e.getModulo() + "'.");
            }
        }
        
        unidades.add(e);
    }
    
    public void moverUnidades()
    {
        for(UnidadOperativa u : this.unidades)
        {
            if(u instanceof Reubicable r)
            {
                ((Reubicable) u).moverA();
            }
            
            else
            {
                System.out.println("No es posible mover esta unidad.");
            }
        }
    }
    
    public void realizarFuncioneBases()
    {
        for(UnidadOperativa u : this.unidades)
        {
            u.reabastecer();
            u.mantenerAtmosfera();
            u.replicar();
        }
    }
    
    public void filtrarPorTipoAtmosfera(TipoAtmosfera a)
    {
        for(UnidadOperativa u : this.unidades)
        {
            if(u.getTipoatmosfera() == a)
            {
                System.out.println("\nLas unidades que tiene la atmosfera " + a + " son:\n");
                System.out.println(u.toString());
            }
        }
    }
    
    public void mostrarUnidades()
    {
        if(this.unidades.isEmpty())
        {
            System.out.println("No hay unidades cargadas.");
        }
        
        else
        {
            for(UnidadOperativa u : this.unidades)
            {
                System.out.println(u.toString());
            }
        }
    }
}
