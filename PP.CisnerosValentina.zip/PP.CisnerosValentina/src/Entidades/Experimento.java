/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author Valentina
 */
public class Experimento extends UnidadOperativa
{
    private int duracionIdeal;

    public Experimento(int duracionIdeal, String numeroID, String modulo, TipoAtmosfera tipoatmosfera) 
    {
        super(numeroID, modulo, tipoatmosfera);
        this.duracionIdeal = duracionIdeal;
    }
    
    @Override
    public void reabastecer() 
    {
        System.out.println("Reaplicando vacunas para mantener al experimento vivo.");
    }

    @Override
    public void mantenerAtmosfera() 
    {
        System.out.println("Manteniendo niveles de oxigeno adaptadas al individuo.");
    }

    @Override
    public void replicar() 
    {
        System.out.println("Replicando ADN.");
    }
    
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        
        sb.append(super.toString());
        sb.append("\nEsta unidad es un: Experimento\n");
        sb.append("Duracion real: ").append(this.duracionIdeal);
        
        return sb.toString();
    }
}
