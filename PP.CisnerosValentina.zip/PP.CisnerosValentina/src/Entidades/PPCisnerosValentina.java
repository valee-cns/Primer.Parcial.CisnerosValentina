/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Entidades;

/**
 *
 * @author Valentina
 */
public class PPCisnerosValentina 
{
    public static void main(String[] args) 
    {
        BaseEspacialInternacional base = new BaseEspacialInternacional("NASA");
        Astronauta a1 = new Astronauta(8, "Laura", "Modulo 1", TipoAtmosfera.PRESURIZADA);
        Robot r1 = new Robot(10, "Bender", "M2", TipoAtmosfera.VACIO);
        Experimento e1 = new Experimento(12, "Experimento 626", "M3", TipoAtmosfera.PRESURIZADA);
        
        Astronauta a2 = new Astronauta(7, "Laura", "Modulo 1", TipoAtmosfera.PRESURIZADA);
        try
        {
            base.agregarUnidadOperativa(a1);
            base.agregarUnidadOperativa(r1);
            base.agregarUnidadOperativa(e1);
            
            base.agregarUnidadOperativa(a2);
        }
        
        catch(ErrorUnidadDuplicada e)
        {
            System.out.println("Error: " + e.getMessage());
        }
        
        System.out.println("\nUnidades registradas:\n");
        base.mostrarUnidades();

        System.out.println("\nMover unidades:\n");
        base.moverUnidades();

        System.out.println("\nFunciones de cada unidad:\n");
        base.realizarFuncioneBases();

        System.out.println("\nFiltrar por atmósfera presurizada:\n");
        base.filtrarPorTipoAtmosfera(TipoAtmosfera.PRESURIZADA);
    }
    
}
