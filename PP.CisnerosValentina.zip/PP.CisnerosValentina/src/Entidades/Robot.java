/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.time.LocalTime;

/**
 *
 * @author Valentina
 */
public class Robot extends UnidadOperativa implements Reubicable
{
    private int autonomiaOperativa;

    public Robot(int autonomiaOperativa, String numeroID, String modulo, TipoAtmosfera tipoatmosfera) 
    {
        super(numeroID, modulo, tipoatmosfera);
        this.autonomiaOperativa = autonomiaOperativa;
    }
    
    //Puede moverse entre modulos
    
    @Override
    public void reabastecer() 
    {
        System.out.println("Recargando las baterías.");
    }

    @Override
    public void mantenerAtmosfera() 
    {
        System.out.println("Verificando atmosfera para manetener funcionalidades.");
    }

    @Override
    public void replicar() 
    {
        System.out.println("Replicando memoria para nuevo robot.");
    }
    
    @Override
    public void moverA() 
    {
        System.out.println("Movieron de módulo al robot.");
    }
    
    @Override
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        
        sb.append(super.toString());
        sb.append("\nEsta unidad es un: Robot\n");
        sb.append("Autonomía operativa: ").append(this.autonomiaOperativa);
        
        return sb.toString();
    }
}
