/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author Valentina
 */
public abstract class UnidadOperativa 
{
    protected String nombreID;
    protected String modulo;
    protected TipoAtmosfera tipoatmosfera;

    public UnidadOperativa(String nombreID, String modulo, TipoAtmosfera tipoatmosfera) 
    {
        this.nombreID = nombreID;
        this.modulo = modulo;
        this.tipoatmosfera = tipoatmosfera;
    }

    public String getNombreID() 
    {
        return nombreID;
    }

    public String getModulo() 
    {
        return modulo;
    }

    public TipoAtmosfera getTipoatmosfera() 
    {
        return tipoatmosfera;
    }
    
    public abstract void reabastecer();
    public abstract void mantenerAtmosfera();
    public abstract void replicar();
    
    public String toString()
    {
        StringBuilder sb = new StringBuilder();
        
        sb.append("\n\nDatos de la Unidad:\n");
        sb.append("Nombre Identitificador: ").append(this.nombreID);
        sb.append("\nModulo en el que se encuentra: ").append(this.modulo);
        sb.append("\nTipo de atmosfera: ").append(this.tipoatmosfera);
        
        return sb.toString();
    }
    
    @Override
    public boolean equals(Object o) 
    {
        if (this == o) return true;
        if (o == null || !(o instanceof UnidadOperativa u)) return false;
        return nombreID.equals(u.nombreID) && modulo.equals(u.modulo);
    }
    
    @Override
    public int hashCode() 
    {
        return java.util.Objects.hash(nombreID, modulo);
    }
}
